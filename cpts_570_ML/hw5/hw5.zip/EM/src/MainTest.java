
public class MainTest {
	public static void main(String[] args){
		EM_core em = new EM_core(5);
		em.iteration();
	}
}
