import os, datetime

def readFile(filename):
	with open(filename) as f:
		lines = f.readlines()
	lines = [x.strip().split(',') for x in lines]

	return lines
	
def weekDay(date):
	year, month, day = date.split('-')
	year = int(year)
	month = int(month)
	day = int(day)
	offset = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
	week   = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday',  'Friday', 'Saturday']
	afterFeb = 1
	if month > 2: 
		afterFeb = 0
	aux = year - 1700 - afterFeb
	# dayOfWeek for 1700/1/1 = 5, Friday
	dayOfWeek  = 5
	# partial sum of days betweem current date and 1700/1/1
	dayOfWeek += (aux + afterFeb) * 365                  
	# leap year correction    
	dayOfWeek += aux / 4 - aux / 100 + (aux + 100) / 400     
	# sum monthly and day offsets
	dayOfWeek += offset[month - 1] + (day - 1)               
	dayOfWeek %= 7
	return week[dayOfWeek]
	
def calculateScore(w1, w2):
	return sum(w1) - sum(w2)

def detectSC(hourly_data, window_size, offset, move_speed):
	hourly_data = hourly_data[1 : len(hourly_data)-1]
	i = 0
	j = i + offset
	score_list = []
	while j + window_size < len(hourly_data):
		w1 = hourly_data[i : i + window_size]
		w2 = hourly_data[j : j + window_size]
		score = sum(map(int, w1)) - sum(map(int, w2))
		score_list.append(score)
		
		i += move_speed
		j += move_speed
	return score_list
	

	
dir = '/home/leozhang/Desktop/fitbit/hour_steps'
if not os.path.exists('../image_vector_data'):
	os.makedirs('../image_vector_data')
dayDict = {}
os.chdir(dir)
for root, dirs, filenames in os.walk(dir):
	for filename in filenames:
		if filename.endswith(".csv"):
			content = readFile(filename)
			for x in content:
				day = weekDay(x[0])
				if day not in dayDict:
					dayDict[day] = []
				dayDict[day].append(x)
			#print dayDict
			monday_list = dayDict['Monday']
			for m in monday_list:
				print detectSC(m, 2, 1, 1)
			exit()
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
