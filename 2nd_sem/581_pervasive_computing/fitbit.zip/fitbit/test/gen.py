
import csv, os
def gen():
	dir = '/home/leozhang/Desktop/fitbit/test/raw'
	#if not os.path.exists('../image_vector_data'):
	#	os.makedirs('../image_vector_data')
	os.chdir(dir)
	print os.getcwd()
	for root, dirs, filenames in os.walk(dir):
		for filename in filenames:
			content = []
			with open(filename) as f:
				r = csv.reader(f)
				for line in r:
					content.append(line[1:len(line)-1])

			with open('../gen/'+filename, 'w+') as f:
				for line in content:
					for hour_steps in line:
						f.write(hour_steps + '\n')

gen()