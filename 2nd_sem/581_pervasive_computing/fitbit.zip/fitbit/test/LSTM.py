# LSTM for international airline passengers problem with regression framing
import numpy, os
import matplotlib.pyplot as plt
from pandas import read_csv
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
# convert an array of values into a dataset matrix
def create_dataset(dataset, look_back=1):
	dataX, dataY = [], []
	for i in range(len(dataset)-look_back-1):
		a = dataset[i:(i+look_back), 0]
		dataX.append(a)
		dataY.append(dataset[i + look_back, 0])
	return numpy.array(dataX), numpy.array(dataY)

def train(filename, window_size, train_iter):
	# fix random seed for reproducibility
	numpy.random.seed(7)
	# load the dataset
	dataframe = read_csv(filename, usecols=[0], engine='python')
	#old = read_csv('a.csv', usecols=[0], engine='python')
	#old = old.values
	dataset = dataframe.values

	dataset = dataset.astype('float32')
	# normalize the dataset
	scaler = MinMaxScaler(feature_range=(0, 1))
	dataset = scaler.fit_transform(dataset)

	# split into train and test sets
	train_size = int(len(dataset) * 0.67)
	test_size = len(dataset) - train_size
	train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
	# reshape into X=t and Y=t+1
	look_back = window_size
	trainX, trainY = create_dataset(train, look_back)
	testX, testY = create_dataset(test, look_back)
	# reshape input to be [samples, time steps, features]
	trainX = numpy.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
	testX = numpy.reshape(testX, (testX.shape[0], 1, testX.shape[1]))
	# create and fit the LSTM network
	model = Sequential()
	model.add(LSTM(4, input_shape=(1, look_back)))
	model.add(Dense(1))
	model.compile(loss='mean_squared_error', optimizer='adam')
	model.fit(trainX, trainY, epochs=train_iter, batch_size=1, verbose=2)
	# make predictions
	trainPredict = model.predict(trainX)
	testPredict = model.predict(testX)
	# invert predictions
	trainPredict = scaler.inverse_transform(trainPredict)
	trainY = scaler.inverse_transform([trainY])
	testPredict = scaler.inverse_transform(testPredict)
	testY = scaler.inverse_transform([testY])

	# calculate root mean squared error
	trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
	print('Train Score: %.2f RMSE' % (trainScore))
	testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:,0]))
	print('Test Score: %.2f RMSE' % (testScore))
	# shift train predictions for plotting
	trainPredictPlot = numpy.empty_like(dataset)
	trainPredictPlot[:, :] = numpy.nan
	trainPredictPlot[look_back:len(trainPredict)+look_back, :] = trainPredict
	# shift test predictions for plotting
	testPredictPlot = numpy.empty_like(dataset)
	testPredictPlot[:, :] = numpy.nan
	testPredictPlot[len(trainPredict)+(look_back*2)+1:len(dataset)-1, :] = testPredict
	print len(trainPredict), len(testPredict)
	# plot baseline and predictions
	#print old
	dataset = scaler.inverse_transform(dataset)
	count = 0
	dif = 0
	total = 0	
	for i in range(look_back, len(trainPredict) + look_back):
 		count+=1
		dif += dataset[i] - trainPredictPlot[i]
		total += dataset[i]
	dif = dif if dif >= 0 else -dif
	test_count = 0
	test_total = 0
	test_dif = 0
	for i in range(len(trainPredict)+(look_back*2)+1, len(dataset)-1):
		test_count += 1
		test_dif += dataset[i] - testPredictPlot[i]
		test_total += dataset[i]
	test_dif = test_dif if test_dif >= 0 else -test_dif	
	names = filename.split('.')
	dif_avg = dif*1.0/count
	total_avg = total*1.0/count
	avg_accuracy = (total_avg-dif_avg)/total_avg

	test_dif_avg = test_dif*1.0/test_count
	test_total_avg = test_total*1.0/test_count
	test_avg_accuracy = (test_total_avg-test_dif_avg)/test_total_avg
	if not os.path.exists('../fig/'+names[0]):
		os.makedirs('../fig/'+names[0])
	with open('../fig/'+names[0]+'/'+'log', 'aw+') as f:
		f.write('Training: window_size = %d, dif = %d, total = %d, dif_avg = %.4f, total_avg = %.4f,' 
			'avg_accuracy = %.4f \n'%(window_size,dif,total,dif_avg,total_avg,avg_accuracy))
		f.write('Testing: window_size = %d, dif = %d, total = %d, dif_avg = %.4f, total_avg = %.4f,' 
			'avg_accuracy = %.4f \n'%(window_size,test_dif,test_total,test_dif_avg,test_total_avg,test_avg_accuracy))
	#print dif, total, dif*1.0/count, total*1.0/count
	plt.figure(1)
	plt.subplot(311)
	plt.plot(dataset)
	#plt.plot(old)
	plt.subplot(312)
	plt.plot(trainPredictPlot, 'r')
	plt.plot(testPredictPlot, 'k')
	
	plt.subplot(313)
	plt.plot(dataset)
	plt.plot(trainPredictPlot, 'r')
	plt.plot(testPredictPlot, 'k')

	plt.savefig('../fig/'+names[0]+'/' + names[0]+'_wl_'+ str(window_size) + '.png')
	plt.clf()
	#plt.close(fig)
	#plt.show(block=False)
	print 'fin'

dir = '/home/leozhang/Desktop/fitbit/test/gen'
	#if not os.path.exists('../image_vector_data'):
	#	os.makedirs('../image_vector_data')
os.chdir(dir)
print os.getcwd()
for root, dirs, filenames in os.walk(dir):
	for f in filenames:
		for i in range(1, 16):
			train(f, i, 150)
			
