import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Main {
	public static void main(String[] args){
		int[] c = {0};
		int[] c1 = {0};
		ArrayList<String[]> gold = getGold("files/pku_test_gold.utf8", c);
		
		ChineseSegmentationTool cst = new ChineseSegmentationTool("files/msr_training.utf8");
		ArrayList<String[]> test = getTest("files/pku_test_gold.utf8", c1, cst);
	    // 19968 40869
	    //System.out.println((char)65315);
		int insertion = 0;
		int deletion = 0;
		int right = 0;
		for (int i = 0; i < gold.size(); i++) {
			int dif = gold.get(i).length - test.get(i).length;
			Set<String> mySet = new HashSet<String>(Arrays.asList(gold.get(i)));
			for(String w: test.get(i)){
				if(mySet.contains(w)) right++;
			}
				
			if (dif < 0) insertion+= dif;
			else deletion += dif;
		}
		System.out.println("****************** RESULT ******************");
		System.out.println("Total Inserstions: \t" + -insertion);
		System.out.println("Total Deletions:   \t" + deletion);
		System.out.println("Total correct word:\t" + right);
		System.out.println("True word count:   \t" + c[0]);
		System.out.println("Test word count:   \t" + c1[0]);	
		System.out.printf("Recall:            \t%.3f\n", right*1.0/c[0]);
		System.out.printf("Precision:         \t%.3f\n", right*1.0/c1[0]);
	}
	
	public static ArrayList<String[]> getTest(String fname, int[] wordCount, ChineseSegmentationTool hmm){
		BufferedReader br=null;
		String line;
		ArrayList<String[]> gold = new ArrayList();
		try {
	        br=new BufferedReader(new InputStreamReader(new FileInputStream(new File(fname)),"utf-8"));
	        while((line=br.readLine())!=null){
	            if("".equals(line.trim()))continue;
	            line = hmm.segmentation(line);
	            String[] tokens = line.split("/");
	            wordCount[0] += tokens.length;
	            gold.add(tokens);
	           
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }finally{
	        try {br.close();}catch (IOException e) {e.printStackTrace();}
	    }
		return gold;
		
	}
	public static ArrayList<String[]> getGold(String fname, int[] wordCount){
		
		BufferedReader br=null;
		String line;
		ArrayList<String[]> gold = new ArrayList();
		try {
	        br=new BufferedReader(new InputStreamReader(new FileInputStream(new File(fname)),"utf-8"));
	        int count = 0;
	        while((line=br.readLine())!=null){
	            if("".equals(line.trim()))continue;
	            line = line.replaceAll("\\pP", " ").trim();
	            String[] tokens = line.split("\\s+");
	            wordCount[0] += tokens.length;
	            gold.add(tokens);
	            count++;
	           
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }finally{
	        try {br.close();}catch (IOException e) {e.printStackTrace();}
	    }
		return gold;
	}
	
}
