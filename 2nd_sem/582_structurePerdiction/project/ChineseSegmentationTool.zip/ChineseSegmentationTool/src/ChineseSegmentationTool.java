import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfInteger;
import be.ac.ulg.montefiore.run.jahmm.OpdfIntegerFactory;
import be.ac.ulg.montefiore.run.jahmm.ViterbiCalculator;

public class ChineseSegmentationTool {
	HashMap<Character, Integer> decodeMap;
	HashMap<Character, Integer> labelMap;
	Hmm<ObservationInteger> hmm;
	int dictSize = 65519;
	long freq[][]=new long[4][4];
    long count[]=new long[4];
    long freqC[][]=new long[4][dictSize];
	char[] labelArray = {'B', 'M', 'E', 'S'};
	double pi[] = {0.5, 0.0, 0.0, 0.5};
	public ChineseSegmentationTool(String trainingFile){
		
		/*
		 * There are 4 kinds of states (labels) for StateTransferMatrix
		 * B --- beginning of a word
		 * E --- ending of a word
		 * M --- middle of a word
		 * S --- single character as a word
		 * Matrix formula: 
		 * Aij = P(Cj|Ci)  =  P(Ci,Cj) / P(Ci) = Count(Ci,Cj) / Count(Ci)
		 * */
		
		labelMap = new HashMap();
		labelMap.put('B', 0);
		labelMap.put('M', 1);
		labelMap.put('E', 2);
		labelMap.put('S', 3);
		//decodeMap = getDecodeMap("files/c6699.txt");
		//System.out.println(decodeMap.get('我'));
		fillUpFrequencyFromFile(trainingFile);
		double[][] transferMatrix = buildTransferStateMatrix(freq, count);
		double[][] mixMatrix = mixMatrix(freqC, count);
		hmm = buildHMM(transferMatrix, mixMatrix);
		
	}
	
	
	private Hmm<ObservationInteger> buildHMM(double[][] transferMatrix, double[][] mixMatrix){
		Hmm<ObservationInteger> hmm=new Hmm <ObservationInteger>(4 ,new OpdfIntegerFactory (dictSize) );
        int i,j;
        for( i=0;i<4;i++){
            hmm.setPi(i, pi[i]);
        }
        for(i=0;i<4;i++){
            for(j=0;j<4;j++){
                hmm.setAij(i, j, transferMatrix[i][j]);
            }
            hmm.setOpdf(i, new OpdfInteger(mixMatrix[i]));
        }
        return hmm;
	}
	
	private List<ObservationInteger> getOseq(String sen){
        List<ObservationInteger> oseq=new ArrayList<ObservationInteger>();
        for (int i = 0; i < sen.length(); i++) {
            oseq.add(new ObservationInteger((int)sen.charAt(i)));
        }
        return oseq;
    }
	
	 private String decode(String sen, int[] seqrs){
        StringBuilder sb = new StringBuilder();
        char ch;
        for(int i=0;i<sen.length();i++){
            sb.append(sen.charAt(i));
            ch=labelArray[seqrs[i]];
            //System.out.println(decodeMap.get(sen.charAt(i)));
            if(ch=='E'||ch=='S')
                sb.append("/");
        }
        return sb.toString();
	 }
	 public String segmentation(String sen){
	 	sen = sen.trim().replaceAll("\\pP", "");
	 	sen = sen.trim().replaceAll("\\s+", "");
        List<ObservationInteger> oseq=getOseq(sen);
        ViterbiCalculator vc=new ViterbiCalculator(oseq, hmm);
        int[] segrs= vc.stateSequence();
        return decode(sen,segrs);
	 }
	
	
	private void fillUpFrequencyFromFile(String fname){
		
		BufferedReader br=null;
        String line;
        try {
            br=new BufferedReader(new InputStreamReader(new FileInputStream(new File(fname)),"utf-8"));
            while((line=br.readLine())!=null){
                if("".equals(line.trim()))continue;
                String lineLabels=encode(line, false); //encode with only labels
                if(lineLabels == null) continue;
                //String test=encode(line, true);
                //fill up freq and count 
                int i, j;
                //count[labelMap.get(line.charAt(0))]++;               
                for(i = 0; i < lineLabels.length()-1; i++){
                	count[labelMap.get(lineLabels.charAt(i))]++;
                	j=i+1;
                	freq[labelMap.get(lineLabels.charAt(i))][labelMap.get(lineLabels.charAt(j))]++;
                }
                //System.out.println("+++ " + line);
                //System.out.println("*** " + lineLabels);
                count[labelMap.get(lineLabels.charAt(i))]++;
                
                String lineChar=encode(line, true); //encode with char and labels
                //fill up freqC and countC
                //System.out.println(line);
                if (lineChar.length() % 2 == 0){
	                for(i = 0; i < lineChar.length(); i+=2){
	                	j=i+1;
	                	int label = labelMap.get(lineChar.charAt(j));
	                	int hanChar = (int)lineChar.charAt(i); //.getOrDefault(lineChar.charAt(i), -1);
	                	if(hanChar != -1)
	                		freqC[label][hanChar]++;
	                }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try {br.close(); }catch (IOException e) {e.printStackTrace();}
        }		
		
	}
	
	/*
     * Encode input content by labeling 4 state label (B, E, M, S)
     * Ignore all punctuation
     * */	
	private String encode(String content, boolean withContent){
		//System.out.println(content);
		if(content == null || content.trim().length() == 0)
			return null;
		StringBuilder rst = new StringBuilder();
		content = content.replaceAll("\\pP", " ").trim(); // remove punctuation
		if(content == null || content.trim().length() == 0)
			return null;
		int start = 0; 
		int end= 0; 
		int len = content.length();
		while(end < len){
			if(Character.isWhitespace(content.charAt(end))){ 				
				if(Character.isWhitespace(content.charAt(start))){ 
					start++;
				}	
				if(end > start){ // found a word
					if(!withContent)
						labelContent(rst, start, end);
					else
						labelContentWithChar(content, rst, start, end);
					start = ++end;
					//System.out.println(end);
				}else{
					end++;
				}
				//System.out.println(start);
			}else{
				end++;
			}
		}
		if(end > start){
			if(!withContent)
				labelContent(rst, start, end);
			else
				labelContentWithChar(content, rst, start, end);
		}
		return rst.toString();
	}
	
	private double[][] buildTransferStateMatrix(long[][] freq, long[] count){
		double[][] tsMatrix = new double[4][4];
		for(int i = 0; i < 4; i++){
            for(int j = 0; j < 4; j++){
            	tsMatrix[i][j]=(double)freq[i][j]/count[i];
            }
        }
		//System.out.println(Arrays.toString(freq[2]));
		//System.out.println(count[2]);
		return tsMatrix;
	}
	private double[][] mixMatrix(long[][] freq, long[] count){
		double[][] tsMatrix = new double[4][dictSize];
		for(int i = 0; i < 4; i++){
            for(int j = 0; j < dictSize; j++){
            	tsMatrix[i][j]=(double)(freq[i][j]+1)/count[i];
            }
        }
		//System.out.println(Arrays.toString(freq[2]));
		//System.out.println(count[2]);
		return tsMatrix;
	}
	private void labelContent(StringBuilder sb, int start, int end){
		if(end - start > 1){ // not a word with single character
			sb.append('B');
			for(int i = 0; i < end - start - 2; i++){
				sb.append('M');
			}
			sb.append('E');
		}else{
			sb.append('S');
		}
		
	}
	private void labelContentWithChar(String content, StringBuilder sb, int start, int end){
		if(end - start > 1){ // not a word with single character
			sb.append(content.charAt(start));
			sb.append('B');
			for(int i = 0; i < end - start - 2; i++){
				sb.append(content.charAt(start+i+1));
				sb.append('M');
			}
			sb.append(content.charAt(end-1));
			sb.append('E');
		}else{
			sb.append(content.charAt(end-1));
			sb.append('S');
		}
		
	}
	
	
	private void print(double[][] A){
        int i,j;
        char[] chs={'B','M','E','S'};
        System.out.println("\t\t"+"B"+"\t\t\t"+"M"+"\t\t\t"+"E"+"\t\t\t"+"S");
        for(i=0;i<4;i++){
            System.out.print(chs[i]+"\t");
            for(j=0;j<4;j++){
                System.out.format("%.12f\t\t",A[i][j]);
                                                                                                                                                          
            }
            System.out.println();
        }       
    }
	
	public static void main(String[] args){
		String[] segs={"检察院鲍绍坤检察长","人们常说生活是一部教科书","改判被告人死刑立即执行",
                "结婚的和尚未结婚的都需要登记","邓颖超生前使用过的物品", 
                "香港是一九九七年回归的","我想吃我妈妈做的面","你 现在 应该 去 幼儿园 了", 
                "一点外语知识 数理化知识也没有还攀什么高峰",
                "“  一点  外语  知识  、  数理化  知识  也  没有  ，  还  攀  什么  高峰  ？",
				"王思斌，男，１９４９年１０月生。"};
		ChineseSegmentationTool cst = new ChineseSegmentationTool("files/msr_training.utf8");
		for (String sen : segs) {
            System.out.println(cst.segmentation(sen));
        }
		//double[][] a = cst.buildTransferStateMatrixFromFile("files/msr_training.utf8");
		//cst.print(a);
		//System.out.println(cst.encode("“  一点  外语  知识  、  数理化  知识  也  没有  ，  还  攀  什么  高峰  ？"));
		//System.out.println(cst.encode("你 现在 应该 去 幼儿园 了"));
	}
}



/*
private HashMap<Character, Integer> getDecodeMap(String dictName){
		HashMap<Character, Integer> map = new HashMap();
		BufferedReader br=null;
        try {
            br=new BufferedReader(new InputStreamReader(new FileInputStream(new File(dictName)),"utf-8"));
            String line ;
            while((line=br.readLine())!=null){
                String[] cc=line.trim().split(":");
                map.put(cc[0].charAt(0),Integer.parseInt(cc[1]));                                           
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
		return map;
	}

*/