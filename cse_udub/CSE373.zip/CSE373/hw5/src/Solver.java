// CSE 373 Homework 5: The Even More Amazing Heap 
// YOU DO NOT NEED TO MODIFY THIS INSTRUCTOR-PROVIDED FILE.
// Your code should work properly with an unmodified version of this file.

public interface Solver {
	// (Comments are intentionally omitted from these abstract method headings,
	//  because we want you to write comments for these methods in your own
	//  words in your PriorityQueueSolver class.)
	
	/** @see Homework spec for details */
	boolean solve(Maze maze);
}
