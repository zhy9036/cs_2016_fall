// TODO: Remove each 'todo' comment once I implement each part!

// TODO: class comment header

import java.util.*;

public class SearchableGraph<V, E> extends AbstractGraph<V, E> {

	// TODO: comment header
	public SearchableGraph() {
		super();
	}
	
	// TODO: comment header
	public SearchableGraph(boolean directed, boolean weighted) {
		super(directed, weighted);
	}
	
	// TODO: comment header
	public boolean isReachable(V v1, V v2) {
		// TODO: implement this method
		return false;
	}
	
	// TODO: comment header
	public List<V> minimumWeightPath(V v1, V v2) {
		// TODO: implement this method
		return null;
	}

	// TODO: comment header
	public List<V> shortestPath(V v1, V v2) {
		// TODO: implement this method
		return null;
	}
}
