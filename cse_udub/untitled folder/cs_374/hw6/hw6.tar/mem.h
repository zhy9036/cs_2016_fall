/*

CSE 374 HW6
YANG ZHANG, YILIN LIU

*/

#ifndef MEM_H
#define MEM_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>

#define HEAD_SIZE 16
#define DEFAULT_MEM 1024

// define a struct which can build one memory block
typedef struct memnode{
	struct memnode* next;
	uintptr_t size;
}memnode;

//pulic method headers
void* getmem(uintptr_t size);
void freemem(void* p);
void get_mem_stats(uintptr_t* total_size, uintptr_t* total_free, uintptr_t* n_free_blocks);
void printheap(FILE* f);
#endif



/*
//total number of getmem plus freemem calls to 
//randomly perform during this test
#define ntrials 10000  

//percent of the total getmem/freemem calls that should be getmem
#define pctget 50 

#define pctlarge 10

#define small_limit 200

#define large_limit 20000

//#define random_seed 200

//initilization of trie structure
typedef struct trieNode{
	char* value;
	struct trieNode* kid[NUM_BRANCH];
}trieNode;
*/