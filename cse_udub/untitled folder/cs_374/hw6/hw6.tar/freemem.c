/*

CSE 374 HW6
YANG ZHANG, YILIN LIU

*/


#include "mem.h"

extern memnode* free_list;
extern memnode* allocated_list;
extern void add_to_free_list(memnode* node);


void deleteP(memnode* list_cursor, memnode* element){
	if(list_cursor != NULL){
		if(list_cursor == element){
			list_cursor = NULL;
		}else{
			while(list_cursor->next != NULL){
				if(list_cursor->next == element){
					list_cursor->next = element->next;
					element->next = NULL;
					return;
				}
				list_cursor = list_cursor->next;
			}
		}
	}
}
