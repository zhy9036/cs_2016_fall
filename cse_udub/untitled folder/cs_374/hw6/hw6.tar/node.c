/*

CSE 374 HW6
YANG ZHANG, YILIN LIU

*/

#include "mem_impl.h"

// method for initializing a new memory block
memnode* ini_node(uintptr_t s){
	memnode* n = (memonode*) malloc(s);
	n->size=s;
	return n;
}