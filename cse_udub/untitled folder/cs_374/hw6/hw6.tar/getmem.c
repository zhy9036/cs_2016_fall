/*

CSE 374 HW6
YANG ZHANG, YILIN LIU

*/

#include "mem.h"
#include "mem_impl.h"


uintptr_t G_TOTAL_SIZE = 0;
memnode* free_list = NULL;
memnode* allocated_list = NULL;

//method for allocating memory for memory block
void* getmem(uintptr_t size){

	if(size<=0){
		return NULL;
	}
	uintptr_t actual_size = (size+HEAD_SIZE) + (HEAD_SIZE - (size % HEAD_SIZE)); 

	if(free_list != NULL){
		return allocateNew(actual_size);
	}

	memnode* cur = free_list;

	// first add header(16 bytes) and then make it a mutiple of 16

	while(cur != NULL){

		if(cur->size > actual_size){ //check if there is enough block for new request

			cur = cur + HEAD_SIZE + cur->size - actual_size;
			
			cur->size = size;
			cur->size = cur->size - actual_size;
			add_to_allocated_list(cur+HEAD_SIZE);
			return (void*) cur+HEAD_SIZE;
		}else if(cur->size == actual_size){
			//delete cur from free_list and add it to the AMA
			deleteP(free_list, cur);
			add_to_allocated_list(cur);
			return (void*) cur+HEAD_SIZE;
		}
		cur = cur->next;
	}
	return allocateNew(actual_size);
}

