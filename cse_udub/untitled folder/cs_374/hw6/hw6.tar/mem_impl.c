#include "mem_impl.h"
#include "mem.h"

extern memnode* free_list;
extern memnode* allocated_list;
extern uintptr_t G_TOTAL_SIZE;


void* allocateNew(uintptr_t actual_size){
	if(actual_size<DEFAULT_MEM){
		memnode* holder = (memnode*) malloc(DEFAULT_MEM + HEAD_SIZE);
		
		// UPTATE: G_TOTAL_SIZE
		G_TOTAL_SIZE += DEFAULT_MEM + HEAD_SIZE;
		
		memnode* used_mem = holder+HEAD_SIZE + DEFAULT_MEM - actual_size;
		used_mem->size = actual_size - HEAD_SIZE;
		used_mem->next = NULL;	
		holder->size = DEFAULT_MEM - actual_size;
		holder->next = NULL;
		add_to_free_list(holder);
		add_to_allocated_list(used_mem);
		return (void*) (used_mem + HEAD_SIZE);
	}else{
		memnode* used_mem = (memnode*) malloc(actual_size);
		
		// UPTATE: G_TOTAL_SIZE
		G_TOTAL_SIZE += actual_size;
		
		used_mem->next = NULL;
		used_mem->size = actual_size - HEAD_SIZE;
		add_to_allocated_list(used_mem);
		return (void*) (used_mem + HEAD_SIZE);
	}
}

void add_to_free_list(memnode* p){
	if(free_list == NULL){
		free_list = p;
	}else{
		memnode* cur = free_list;
		while(cur->next!=NULL){
			cur = cur->next;
		}
		cur->next = p;
	}
}

void add_to_allocated_list(memnode* p){
	if(allocated_list == NULL){
		allocated_list = p;
	}else{
		memnode* cur = allocated_list;
		while(cur->next!=NULL){
			cur = cur->next;
		}
		cur->next = p;
	}
}

// method for release allocated memory block
void freemem(void* p){
	if(p == NULL){
		return;
	}

	//case 1: check if p is adjacent to one of the free_list node
	memnode* cursor = free_list;
	while(cursor != NULL){
		if((memnode*)(cursor + HEAD_SIZE + cursor->size + HEAD_SIZE) == p){
			cursor -> size = cursor -> size + ((memnode*)(p-16))->size + HEAD_SIZE;
			//delete p from ALA;
			deleteP(allocated_list, ((memnode*)(p-16)));
			return; 
		}
		cursor = cursor->next;
	}

	add_to_free_list(p);
	//delete p from ALA;
	deleteP(allocated_list, ((memnode*)(p-16)));
}