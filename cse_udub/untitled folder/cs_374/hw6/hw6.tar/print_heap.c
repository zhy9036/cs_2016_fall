/*

CSE 374 HW6
YANG ZHANG, YILIN LIU

*/

#include "mem.h"

extern memnode* free_list;
//method for printing heap info
void printheap(FILE* f){
	// check input file validity
	if(f == NULL){
		printf("File Error!\n");
		return;
	}
	memnode* cursor = free_list;

	while(cursor != NULL){
		fprintf(f, "address: %p length: %d", cursor, (int) cursor->size);
		cursor = cursor -> next;
	}

}
