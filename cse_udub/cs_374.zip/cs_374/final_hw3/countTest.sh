#!/bin/bash

count=1;
count=$(($count+1))
echo $count