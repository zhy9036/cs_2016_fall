#Yang Zhang
#CSE 374 HW3
#Readme
#Fri Jan 24 15:22:21 PST 2014

I used sed command to remove everything before the pattern "http://" to isolate all the correct URLs, and then I scaned through the html file and found that those websites "100best", "babelfish" and "electoral" should not be shown in the result, then I used sed to remove above URLs. 