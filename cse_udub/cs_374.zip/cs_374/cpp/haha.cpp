#include <iostream>

int main(){

	std::cout << "first"<<std::endl;

	return 1;
}