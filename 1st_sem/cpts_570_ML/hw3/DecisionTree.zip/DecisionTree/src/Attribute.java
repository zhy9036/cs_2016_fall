import java.util.Map;

public class Attribute implements Comparable<Attribute>{
	
	public double IG; // information gain
	private String name;
	private Map<Integer, int[]> values;
	
	public Attribute(String name, int[] counts, Map<Integer, int[]> values){
		this.name = name;
		this.values = values;
		this.IG = calculateIG(counts, values);
	}
	
	public String getName(){
		return name;
	}
	
	
	public Map<Integer, int[]> getValues(){
		return values;
	}
	private double calculateIG(int[] counts, Map<Integer, int[]> values){
		
		
		double IG = calculateEntropy(counts);
		//sSystem.out.println(IG);
		int totalCount = counts[0] + counts[1];
		
		for(int v : values.keySet()){
			int[] cnt = values.get(v);
			int totalCount_v = cnt[0] + cnt[1];
			//System.out.println("result = " + (1.0*totalCount_v/totalCount));
			IG -= (1.0*totalCount_v/totalCount) * calculateEntropy(cnt);
		}
		//System.out.println("IG = " + IG);
		return IG;
	}
	
	private double calculateEntropy(int[] counts){
		int totalCount = counts[0] + counts[1];
		
		double yesRatio = (1.0*counts[0]/totalCount);
		double noRatio = (1.0*counts[1]/totalCount);
		
		double entropyS = (yesRatio*noRatio > 0.0)? -yesRatio*Math.log(yesRatio) 
				- noRatio*Math.log(noRatio) : 0.0;
		//System.out.println(entropyS);
		return entropyS;
	}

	@Override
	public int compareTo(Attribute other) {
		// TODO Auto-generated method stub
		return (this.IG > other.IG)? -1 : 1;
	}
}
