import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

public class TreeTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//Set<Map<String, Integer>> train = readFile("data_sets1/test_set.csv");
		Set<Map<String, Integer>>  validation1 = readFile("data_sets1/validation_set.csv");
		Set<Map<String, Integer>> test1 = readFile("data_sets1/test_set.csv");
		Set<Map<String, Integer>>  validation2 = readFile("data_sets2/validation_set.csv");
		Set<Map<String, Integer>> test2 = readFile("data_sets2/test_set.csv");
		
		Set<Map<String, Integer>> train1 = readFile("data_sets1/training_set.csv");
		PriorityQueue<Attribute> atr1 = getAtrs("data_sets1/training_set.csv");
		DTree tree1 = new DTree(atr1, train1);
		
		Set<Map<String, Integer>> train2 = readFile("data_sets2/training_set.csv");
		PriorityQueue<Attribute> atr2 = getAtrs("data_sets2/training_set.csv");
		DTree tree2 = new DTree(atr2, train2);
		
		
		DtreeNode root1 = tree1.root;
		double accuracyValid1 = test(root1, validation1, true);
		double accuracyTest1 = test(root1, test1, true);
		System.out.println("The validation accuracy for Tree 1: " + accuracyValid1);
		System.out.println("The testing accuracy for Tree 1: " + accuracyTest1);
		
		pruning(root1, root1, validation1);
		double accuracyValid11 = test(root1, validation1, true);
		double accuracyTest11 = test(root1, test1, true);		
		System.out.println("The validation accuracy for pruned Tree 1: " + accuracyValid11);
		System.out.println("The testing accuracy for pruned Tree 1: " + accuracyTest11);
		
		DtreeNode root2 = tree2.root;
		double accuracyValid2 = test(root2, validation2, true);
		double accuracyTest2 = test(root2, test2, true);
		System.out.println("The validation accuracy for Tree 2: " + accuracyValid2);
		System.out.println("The testing accuracy for Tree 2: " + accuracyTest2);	
		
		pruning(root2, root2, validation2);
		double accuracyValid22 = test(root2, validation2, true);
		double accuracyTest22 = test(root2, test2, true);
		System.out.println("The validation accuracy for pruned Tree 2: " + accuracyValid22);
		System.out.println("The testing accuracy for pruned Tree 2: " + accuracyTest22);

	}
	// pruning the d-tree in pre-order
	private static void pruning(DtreeNode root, DtreeNode cur, Set<Map<String, Integer>> validation){
		if(cur != null && cur.label == -1){
			
			
			double accuracy = test(root, validation, false);
			DtreeNode subLeft = cur.left;
			DtreeNode subRight = cur.right;
			cur.left = new DtreeNode(subLeft.majorityLabel);
			double accuracyLeft = test(root, validation, false);
			if(accuracyLeft < accuracy)
				cur.left = subLeft;
			else
				accuracy = accuracyLeft;
			cur.right = new DtreeNode(subRight.majorityLabel);
			double accuracyRight = test(root, validation, false);
			if(accuracyRight < accuracy)
				cur.right = subRight;
			pruning(root, cur.left, validation);
			pruning(root, cur.right, validation);
		}
	}
	private static double test(DtreeNode root, Set<Map<String, Integer>> data, boolean ifmatrix){
		int[][] matrix = new int[2][2];
		int count = 0;
		for(Map<String, Integer> m : data){
			DtreeNode cur = root;
			while(cur.label == -1){
				
				int path = m.get(cur.atr);
			
				cur = (path == 1)? cur.left:cur.right;
			}
			if(cur.label == m.get("Class")){
				count++;
				matrix[cur.label][cur.label]++;
			}else
				matrix[m.get("Class")][cur.label]++;
		}
		if(ifmatrix){
			System.out.println("  " + "~0" + " ~1");
			for(int i = 0; i < 2; i++){
				System.out.print(i);
				for(int j = 0; j < 2; j++)
					System.out.print(" "+matrix[i][j]);
				System.out.println();
			}
		}
		return count*1.0/data.size();
	}
	private static PriorityQueue<Attribute> getAtrs(String fname) throws IOException{
		PriorityQueue<Attribute> atr = new PriorityQueue<Attribute>();
		int[][][] stats = null;
		
		Set<Map<String, Integer>> data = new HashSet<Map<String, Integer>>();
		FileInputStream fis = new FileInputStream(new File(fname));
		//Construct BufferedReader from InputStreamReader
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));		
		String line;
		String[] atrs = null;
		while((line=br.readLine()) != null){
			
			if(!line.matches("\\s*")){
				if(line.startsWith("X")){
					atrs = line.split(",");
					stats = new int[atrs.length][2][2];
				}else{
					String[] val = line.split(",");
					for(int i = 0; i<val.length; i++){
						if(val[i].equals("0")){
							if(val[val.length-1].equals("0"))
								stats[i][0][0]++;
							else
								stats[i][0][1]++;
						}else{
							if(val[val.length-1].equals("0"))
								stats[i][1][0]++;
							else
								stats[i][1][1]++;
						}
					}
				}
			}
		}
		br.close();
		int[] totalCount = new int[]{stats[atrs.length-1][0][0],stats[atrs.length-1][1][1]};
		
		for(int i = 0; i < atrs.length-1; i++){
			String name = atrs[i];
			Map<Integer, int[]> m = new HashMap<Integer, int[]>();
			int[][] tmp = stats[i];
			m.put(1, tmp[1]);
			m.put(0, tmp[0]);
			atr.add(new Attribute(name, totalCount, m));
		}
		//System.out.println(totalCount[0] + totalCount[1]);
		return atr;
	}
	
	@SuppressWarnings("null")
	public static Set<Map<String, Integer>> readFile(String fname) throws IOException{
		Set<Map<String, Integer>> data = new HashSet<Map<String, Integer>>();
		FileInputStream fis = new FileInputStream(new File(fname));
		//Construct BufferedReader from InputStreamReader
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		
		String line;
		String[] atrs = null;
		while((line=br.readLine()) != null){
			Map<String, Integer> tmp = new HashMap<String, Integer>(); 
			
			if(!line.matches("\\s*")){
				//System.out.println("this is the " +line);
				if(line.startsWith("X")){
					atrs = line.split(",");
				}else{
					String[] val = line.split(",");
					for(int i = 0; i<val.length; i++){
						//System.out.println(i);
						//System.out.println(atrs.length);
						tmp.put(atrs[i], Integer.valueOf(val[i]));
					}
					data.add(tmp);
				}
				
			}
		}
		br.close();
		return data;	
	}

}
