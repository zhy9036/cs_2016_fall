import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

public class DTree {
	DtreeNode root;
	public DTree(PriorityQueue<Attribute> attrs, 
			Set<Map<String, Integer>> data){
		root = constructTree(attrs, data);
	}
	
	
	// construct the decision tree by ID3
	private DtreeNode constructTree(PriorityQueue<Attribute> attrs, 
			Set<Map<String, Integer>> data){
		
		DtreeNode curRoot = null;
		int countTrue = 0;
		int countFalse = 0;
		for(Map<String, Integer> m : data){
			if(m.get("Class") == 1)
				countTrue++;
			else
				countFalse++;
		}
		// 1 --> true, 0 --> false
		if(countTrue == 0) return new DtreeNode(0);
		if(countFalse == 0) return new DtreeNode(1);
		if(attrs.size()>0){
			Attribute atr = attrs.poll(); // get the atr with the highest IG and remove it
			
			if(atr == null) System.out.println("null");
			curRoot = new DtreeNode(atr.getName(), countTrue, countFalse);
			Map<Integer, int[]> values = atr.getValues();
			//for(int v : values.keySet()){
				Set<Map<String, Integer>> subset1 = getSubset(data, atr.getName(), 1);
				Set<Map<String, Integer>> subset0 = getSubset(data, atr.getName(), 0);
				//if(v ==1 ){
					curRoot.left = constructTree(new PriorityQueue<Attribute>(attrs), subset1); 
				//}else{
					curRoot.right = constructTree(new PriorityQueue<Attribute>(attrs), subset0); 
				//}
				
			//}
		}
		return curRoot;
		
	}
	
	private Set<Map<String, Integer>> getSubset(Set<Map<String, Integer>> data, 
			String atrName, int value){
		Set<Map<String, Integer>> subset = new HashSet<Map<String, Integer>>();
		for(Map<String, Integer> m : data){
			if(m.get(atrName) == value)
				subset.add(m);
		}
		return subset;
	}
}
