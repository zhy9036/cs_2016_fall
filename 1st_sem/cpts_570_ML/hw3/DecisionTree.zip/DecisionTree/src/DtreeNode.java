
public class DtreeNode {
	DtreeNode left;
	DtreeNode right;
	String atr;
	int label;
	int majorityLabel;
	public DtreeNode(String atr, int tc, int fc){
		left = null;
		right = null;
		this.atr = atr;
		this.majorityLabel = (tc > fc)? 1 : 0;
		this.label = -1;
	}
	
	// create a leaf node
	public DtreeNode(int label){
		left = null;
		right = null;
		this.label = label;
		this.majorityLabel = label;
	}
}
